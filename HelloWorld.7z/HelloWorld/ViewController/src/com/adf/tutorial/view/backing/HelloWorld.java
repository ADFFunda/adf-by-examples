package com.adf.tutorial.view.backing;


import javax.faces.component.UIComponent;
import javax.faces.context.FacesContext;

import oracle.adf.view.rich.component.rich.RichDocument;
import oracle.adf.view.rich.component.rich.RichForm;
import oracle.adf.view.rich.component.rich.input.RichInputText;
import oracle.adf.view.rich.component.rich.layout.RichDecorativeBox;
import oracle.adf.view.rich.component.rich.layout.RichPanelGroupLayout;
import oracle.adf.view.rich.component.rich.nav.RichCommandButton;
import oracle.adf.view.rich.component.rich.output.RichOutputText;

public class HelloWorld {
    private RichForm f1;
    private RichDocument d1;
    private RichDecorativeBox db1;
    private RichInputText it1;
    private RichPanelGroupLayout pgl1;
    private RichOutputText ot1;
    private RichPanelGroupLayout pgl2;
    private RichCommandButton cb2;

    public void setF1(RichForm f1) {
        this.f1 = f1;
    }

    public RichForm getF1() {
        return f1;
    }

    public void setD1(RichDocument d1) {
        this.d1 = d1;
    }

    public RichDocument getD1() {
        return d1;
    }

    public void setDb1(RichDecorativeBox db1) {
        this.db1 = db1;
    }

    public RichDecorativeBox getDb1() {
        return db1;
    }

    public void setIt1(RichInputText it1) {
        this.it1 = it1;
    }

    public RichInputText getIt1() {
        return it1;
    }

    public void setPgl1(RichPanelGroupLayout pgl1) {
        this.pgl1 = pgl1;
    }

    public RichPanelGroupLayout getPgl1() {
        return pgl1;
    }


    public void setOt1(RichOutputText ot1) {
        this.ot1 = ot1;
    }

    public RichOutputText getOt1() {
        return ot1;
    }

    public String cb1_action() {
        // Add event code here...
        RichInputText inputText = (RichInputText)getIt1();
        System.out.println("I was here: "+(String)inputText.getValue());
        String name = "Hello "+ (String)inputText.getValue();
//        ot1.setValue(name);
        ot1.setValue(name);
        System.out.println("I was here");
        return null;
    }

    public void setPgl2(RichPanelGroupLayout pgl2) {
        this.pgl2 = pgl2;
    }

    public RichPanelGroupLayout getPgl2() {
        return pgl2;
    }


    public void setCb2(RichCommandButton cb2) {
        this.cb2 = cb2;
    }

    public RichCommandButton getCb2() {
        return cb2;
    }

    public String cb2_action() {
        // Add event code here...
        RichInputText inputText = (RichInputText)getIt1();
        System.out.println("I was here: "+(String)inputText.getValue());
        String name = "Hello "+ (String)inputText.getValue();
        ot1.setValue(name);
        return null;
    }

    public void it1_validator(FacesContext facesContext,
                              UIComponent uIComponent, Object object) {
        System.out.println("validator");
        
        ot1.setValue("as");
        // Add event code here...
    }
}
